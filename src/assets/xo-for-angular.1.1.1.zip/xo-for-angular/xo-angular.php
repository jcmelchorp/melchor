<?php
/*
Plugin Name: Xo for Angular
Plugin URI: https://angularxo.io
Description: Angular theme development in WordPress with templates and a powerful API.
Version: 1.1.1
Author: Travis Brown
Author URI: http://www.xodustech.com
Text Domain: xo
Domain Path: /Languages
*/

require_once('Includes/Xo.php');
$Xo = new Xo(dirname(__FILE__));